--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg120+2)
-- Dumped by pg_dump version 17.5 (Ubuntu 17.5-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ecom_transaction;
--
-- Name: ecom_transaction; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE ecom_transaction WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE ecom_transaction OWNER TO admin;

\connect ecom_transaction

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: trx; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA trx;


ALTER SCHEMA trx OWNER TO admin;

--
-- Name: CustomerBalanceType; Type: TYPE; Schema: trx; Owner: admin
--

CREATE TYPE trx."CustomerBalanceType" AS ENUM (
    'Withdrawal',
    'Deposit',
    'Transaction'
);


ALTER TYPE trx."CustomerBalanceType" OWNER TO admin;

--
-- Name: Roles; Type: TYPE; Schema: trx; Owner: admin
--

CREATE TYPE trx."Roles" AS ENUM (
    'Admin',
    'SuperAdmin',
    'Customer'
);


ALTER TYPE trx."Roles" OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Customer; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."Customer" (
    id integer NOT NULL,
    username text NOT NULL,
    balance integer NOT NULL,
    "apiKey" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdBy" integer,
    password text,
    name text
);


ALTER TABLE trx."Customer" OWNER TO admin;

--
-- Name: CustomerBalanceHistory; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."CustomerBalanceHistory" (
    id integer NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    bf_balance integer NOT NULL,
    af_balance integer NOT NULL,
    amount integer NOT NULL,
    "customerId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ref_id text,
    type trx."CustomerBalanceType" NOT NULL
);


ALTER TABLE trx."CustomerBalanceHistory" OWNER TO admin;

--
-- Name: CustomerBalanceHistory_id_seq; Type: SEQUENCE; Schema: trx; Owner: admin
--

CREATE SEQUENCE trx."CustomerBalanceHistory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trx."CustomerBalanceHistory_id_seq" OWNER TO admin;

--
-- Name: CustomerBalanceHistory_id_seq; Type: SEQUENCE OWNED BY; Schema: trx; Owner: admin
--

ALTER SEQUENCE trx."CustomerBalanceHistory_id_seq" OWNED BY trx."CustomerBalanceHistory".id;


--
-- Name: Customer_id_seq; Type: SEQUENCE; Schema: trx; Owner: admin
--

CREATE SEQUENCE trx."Customer_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trx."Customer_id_seq" OWNER TO admin;

--
-- Name: Customer_id_seq; Type: SEQUENCE OWNED BY; Schema: trx; Owner: admin
--

ALTER SEQUENCE trx."Customer_id_seq" OWNED BY trx."Customer".id;


--
-- Name: ExtProductToSupplierJunction; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ExtProductToSupplierJunction" (
    product_id integer NOT NULL,
    item_id text NOT NULL,
    qty integer NOT NULL
);


ALTER TABLE trx."ExtProductToSupplierJunction" OWNER TO admin;

--
-- Name: ExternalAdminUsers; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ExternalAdminUsers" (
    "userId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE trx."ExternalAdminUsers" OWNER TO admin;

--
-- Name: ExternalProduct; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ExternalProduct" (
    item_id text NOT NULL,
    game_name text NOT NULL,
    item_name text NOT NULL,
    server_name text NOT NULL,
    group_name text NOT NULL,
    stock integer NOT NULL,
    min_order integer NOT NULL,
    price integer NOT NULL,
    "createdBy" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE trx."ExternalProduct" OWNER TO admin;

--
-- Name: ExternalSupplierProduct; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ExternalSupplierProduct" (
    id integer NOT NULL,
    brand text NOT NULL,
    category text NOT NULL,
    price integer NOT NULL,
    "actualPrice" integer,
    "createdBy" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    code text NOT NULL,
    "desc" text NOT NULL,
    end_cut_off text NOT NULL,
    multi boolean NOT NULL,
    start_cut_off text NOT NULL,
    status boolean NOT NULL,
    unlimited_stock boolean NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    stock integer NOT NULL
);


ALTER TABLE trx."ExternalSupplierProduct" OWNER TO admin;

--
-- Name: ExternalSupplierProduct_id_seq; Type: SEQUENCE; Schema: trx; Owner: admin
--

CREATE SEQUENCE trx."ExternalSupplierProduct_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trx."ExternalSupplierProduct_id_seq" OWNER TO admin;

--
-- Name: ExternalSupplierProduct_id_seq; Type: SEQUENCE OWNED BY; Schema: trx; Owner: admin
--

ALTER SEQUENCE trx."ExternalSupplierProduct_id_seq" OWNED BY trx."ExternalSupplierProduct".id;


--
-- Name: ExternalTransactionBatch; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ExternalTransactionBatch" (
    batch_id text NOT NULL,
    "createdBy" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE trx."ExternalTransactionBatch" OWNER TO admin;

--
-- Name: ExternalTransactionHistory; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ExternalTransactionHistory" (
    ref_id text NOT NULL,
    username text NOT NULL,
    buyer_sku_code text NOT NULL,
    customer_no text NOT NULL,
    sign text NOT NULL,
    customer_id integer,
    status text,
    customer_username text,
    source text,
    item_price integer,
    profit integer,
    "createdBy" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    order_id integer,
    "externalTransactionBatchBatch_id" text,
    rc text NOT NULL,
    sn text NOT NULL
);


ALTER TABLE trx."ExternalTransactionHistory" OWNER TO admin;

--
-- Name: ExternalUser; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ExternalUser" (
    id integer NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    balance integer NOT NULL,
    role trx."Roles" NOT NULL,
    "apiKey" text,
    "isCustomer" boolean NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "externalAdminUsersUserId" integer
);


ALTER TABLE trx."ExternalUser" OWNER TO admin;

--
-- Name: ExternalUserBalanceHistory; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ExternalUserBalanceHistory" (
    id integer NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    type trx."CustomerBalanceType" NOT NULL,
    bf_balance integer NOT NULL,
    af_balance integer NOT NULL,
    amount integer NOT NULL,
    ref_id text NOT NULL,
    "userId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE trx."ExternalUserBalanceHistory" OWNER TO admin;

--
-- Name: ExternalUserBalanceHistory_id_seq; Type: SEQUENCE; Schema: trx; Owner: admin
--

CREATE SEQUENCE trx."ExternalUserBalanceHistory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trx."ExternalUserBalanceHistory_id_seq" OWNER TO admin;

--
-- Name: ExternalUserBalanceHistory_id_seq; Type: SEQUENCE OWNED BY; Schema: trx; Owner: admin
--

ALTER SEQUENCE trx."ExternalUserBalanceHistory_id_seq" OWNED BY trx."ExternalUserBalanceHistory".id;


--
-- Name: ExternalUser_id_seq; Type: SEQUENCE; Schema: trx; Owner: admin
--

CREATE SEQUENCE trx."ExternalUser_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trx."ExternalUser_id_seq" OWNER TO admin;

--
-- Name: ExternalUser_id_seq; Type: SEQUENCE OWNED BY; Schema: trx; Owner: admin
--

ALTER SEQUENCE trx."ExternalUser_id_seq" OWNED BY trx."ExternalUser".id;


--
-- Name: ItemkuOrder; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ItemkuOrder" (
    price integer NOT NULL,
    quantity integer NOT NULL,
    status text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    delivery_info text,
    delivery_info_field text,
    game_name text NOT NULL,
    is_from_ads boolean DEFAULT false NOT NULL,
    order_id integer NOT NULL,
    order_income integer NOT NULL,
    order_number text NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    required_information jsonb NOT NULL,
    using_delivery_info integer DEFAULT 0 NOT NULL
);


ALTER TABLE trx."ItemkuOrder" OWNER TO admin;

--
-- Name: ItemkuProduct; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ItemkuProduct" (
    item_id integer NOT NULL,
    game_name text NOT NULL,
    server_name text NOT NULL,
    group_name text NOT NULL,
    min_order integer NOT NULL,
    price integer NOT NULL,
    product_id integer,
    "createdBy" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    stock integer NOT NULL,
    item_name text NOT NULL
);


ALTER TABLE trx."ItemkuProduct" OWNER TO admin;

--
-- Name: Owner; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."Owner" (
    id integer NOT NULL,
    name text NOT NULL,
    balance integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdBy" integer,
    percentage integer
);


ALTER TABLE trx."Owner" OWNER TO admin;

--
-- Name: Owner_id_seq; Type: SEQUENCE; Schema: trx; Owner: admin
--

CREATE SEQUENCE trx."Owner_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trx."Owner_id_seq" OWNER TO admin;

--
-- Name: Owner_id_seq; Type: SEQUENCE OWNED BY; Schema: trx; Owner: admin
--

ALTER SEQUENCE trx."Owner_id_seq" OWNED BY trx."Owner".id;


--
-- Name: ProductPrice; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."ProductPrice" (
    id integer NOT NULL,
    brand text NOT NULL,
    category text NOT NULL,
    price integer NOT NULL,
    buyer_sku_code text NOT NULL,
    product_name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "actualPrice" integer,
    "createdBy" integer
);


ALTER TABLE trx."ProductPrice" OWNER TO admin;

--
-- Name: ProductPrice_id_seq; Type: SEQUENCE; Schema: trx; Owner: admin
--

CREATE SEQUENCE trx."ProductPrice_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trx."ProductPrice_id_seq" OWNER TO admin;

--
-- Name: ProductPrice_id_seq; Type: SEQUENCE OWNED BY; Schema: trx; Owner: admin
--

ALTER SEQUENCE trx."ProductPrice_id_seq" OWNED BY trx."ProductPrice".id;


--
-- Name: TransactionHistory; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."TransactionHistory" (
    ref_id text NOT NULL,
    username text NOT NULL,
    buyer_sku_code text NOT NULL,
    customer_no text NOT NULL,
    sign text NOT NULL,
    customer_id integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    profit integer,
    status text,
    "createdBy" integer,
    item_price integer,
    customer_username text,
    source text,
    order_id integer
);


ALTER TABLE trx."TransactionHistory" OWNER TO admin;

--
-- Name: User; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx."User" (
    id integer NOT NULL,
    name text NOT NULL,
    role trx."Roles" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    password text NOT NULL,
    username text NOT NULL
);


ALTER TABLE trx."User" OWNER TO admin;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: trx; Owner: admin
--

CREATE SEQUENCE trx."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trx."User_id_seq" OWNER TO admin;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: trx; Owner: admin
--

ALTER SEQUENCE trx."User_id_seq" OWNED BY trx."User".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: trx; Owner: admin
--

CREATE TABLE trx._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE trx._prisma_migrations OWNER TO admin;

--
-- Name: Customer id; Type: DEFAULT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."Customer" ALTER COLUMN id SET DEFAULT nextval('trx."Customer_id_seq"'::regclass);


--
-- Name: CustomerBalanceHistory id; Type: DEFAULT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."CustomerBalanceHistory" ALTER COLUMN id SET DEFAULT nextval('trx."CustomerBalanceHistory_id_seq"'::regclass);


--
-- Name: ExternalSupplierProduct id; Type: DEFAULT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalSupplierProduct" ALTER COLUMN id SET DEFAULT nextval('trx."ExternalSupplierProduct_id_seq"'::regclass);


--
-- Name: ExternalUser id; Type: DEFAULT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalUser" ALTER COLUMN id SET DEFAULT nextval('trx."ExternalUser_id_seq"'::regclass);


--
-- Name: ExternalUserBalanceHistory id; Type: DEFAULT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalUserBalanceHistory" ALTER COLUMN id SET DEFAULT nextval('trx."ExternalUserBalanceHistory_id_seq"'::regclass);


--
-- Name: Owner id; Type: DEFAULT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."Owner" ALTER COLUMN id SET DEFAULT nextval('trx."Owner_id_seq"'::regclass);


--
-- Name: ProductPrice id; Type: DEFAULT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ProductPrice" ALTER COLUMN id SET DEFAULT nextval('trx."ProductPrice_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."User" ALTER COLUMN id SET DEFAULT nextval('trx."User_id_seq"'::regclass);


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3575.dat

--
-- Data for Name: CustomerBalanceHistory; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3583.dat

--
-- Data for Name: ExtProductToSupplierJunction; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3596.dat

--
-- Data for Name: ExternalAdminUsers; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3588.dat

--
-- Data for Name: ExternalProduct; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3592.dat

--
-- Data for Name: ExternalSupplierProduct; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3594.dat

--
-- Data for Name: ExternalTransactionBatch; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3595.dat

--
-- Data for Name: ExternalTransactionHistory; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3591.dat

--
-- Data for Name: ExternalUser; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3587.dat

--
-- Data for Name: ExternalUserBalanceHistory; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3590.dat

--
-- Data for Name: ItemkuOrder; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3584.dat

--
-- Data for Name: ItemkuProduct; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3585.dat

--
-- Data for Name: Owner; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3579.dat

--
-- Data for Name: ProductPrice; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3577.dat

--
-- Data for Name: TransactionHistory; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3573.dat

--
-- Data for Name: User; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3581.dat

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: trx; Owner: admin
--

\i $$PATH$$/3572.dat

--
-- Name: CustomerBalanceHistory_id_seq; Type: SEQUENCE SET; Schema: trx; Owner: admin
--

SELECT pg_catalog.setval('trx."CustomerBalanceHistory_id_seq"', 1, false);


--
-- Name: Customer_id_seq; Type: SEQUENCE SET; Schema: trx; Owner: admin
--

SELECT pg_catalog.setval('trx."Customer_id_seq"', 1, false);


--
-- Name: ExternalSupplierProduct_id_seq; Type: SEQUENCE SET; Schema: trx; Owner: admin
--

SELECT pg_catalog.setval('trx."ExternalSupplierProduct_id_seq"', 51, true);


--
-- Name: ExternalUserBalanceHistory_id_seq; Type: SEQUENCE SET; Schema: trx; Owner: admin
--

SELECT pg_catalog.setval('trx."ExternalUserBalanceHistory_id_seq"', 1, false);


--
-- Name: ExternalUser_id_seq; Type: SEQUENCE SET; Schema: trx; Owner: admin
--

SELECT pg_catalog.setval('trx."ExternalUser_id_seq"', 1, false);


--
-- Name: Owner_id_seq; Type: SEQUENCE SET; Schema: trx; Owner: admin
--

SELECT pg_catalog.setval('trx."Owner_id_seq"', 2, true);


--
-- Name: ProductPrice_id_seq; Type: SEQUENCE SET; Schema: trx; Owner: admin
--

SELECT pg_catalog.setval('trx."ProductPrice_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: trx; Owner: admin
--

SELECT pg_catalog.setval('trx."User_id_seq"', 1, true);


--
-- Name: CustomerBalanceHistory CustomerBalanceHistory_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."CustomerBalanceHistory"
    ADD CONSTRAINT "CustomerBalanceHistory_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: ExtProductToSupplierJunction ExtProductToSupplierJunction_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExtProductToSupplierJunction"
    ADD CONSTRAINT "ExtProductToSupplierJunction_pkey" PRIMARY KEY (product_id, item_id);


--
-- Name: ExternalAdminUsers ExternalAdminUsers_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalAdminUsers"
    ADD CONSTRAINT "ExternalAdminUsers_pkey" PRIMARY KEY ("userId");


--
-- Name: ExternalProduct ExternalProduct_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalProduct"
    ADD CONSTRAINT "ExternalProduct_pkey" PRIMARY KEY (item_id);


--
-- Name: ExternalSupplierProduct ExternalSupplierProduct_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalSupplierProduct"
    ADD CONSTRAINT "ExternalSupplierProduct_pkey" PRIMARY KEY (id);


--
-- Name: ExternalTransactionBatch ExternalTransactionBatch_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalTransactionBatch"
    ADD CONSTRAINT "ExternalTransactionBatch_pkey" PRIMARY KEY (batch_id);


--
-- Name: ExternalTransactionHistory ExternalTransactionHistory_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalTransactionHistory"
    ADD CONSTRAINT "ExternalTransactionHistory_pkey" PRIMARY KEY (ref_id);


--
-- Name: ExternalUserBalanceHistory ExternalUserBalanceHistory_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalUserBalanceHistory"
    ADD CONSTRAINT "ExternalUserBalanceHistory_pkey" PRIMARY KEY (id);


--
-- Name: ExternalUser ExternalUser_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalUser"
    ADD CONSTRAINT "ExternalUser_pkey" PRIMARY KEY (id);


--
-- Name: ItemkuOrder ItemkuOrder_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ItemkuOrder"
    ADD CONSTRAINT "ItemkuOrder_pkey" PRIMARY KEY (order_id);


--
-- Name: ItemkuProduct ItemkuProduct_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ItemkuProduct"
    ADD CONSTRAINT "ItemkuProduct_pkey" PRIMARY KEY (item_id);


--
-- Name: Owner Owner_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."Owner"
    ADD CONSTRAINT "Owner_pkey" PRIMARY KEY (id);


--
-- Name: ProductPrice ProductPrice_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ProductPrice"
    ADD CONSTRAINT "ProductPrice_pkey" PRIMARY KEY (id);


--
-- Name: TransactionHistory TransactionHistory_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."TransactionHistory"
    ADD CONSTRAINT "TransactionHistory_pkey" PRIMARY KEY (ref_id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: ExternalProduct_item_id_key; Type: INDEX; Schema: trx; Owner: admin
--

CREATE UNIQUE INDEX "ExternalProduct_item_id_key" ON trx."ExternalProduct" USING btree (item_id);


--
-- Name: ExternalSupplierProduct_code_key; Type: INDEX; Schema: trx; Owner: admin
--

CREATE UNIQUE INDEX "ExternalSupplierProduct_code_key" ON trx."ExternalSupplierProduct" USING btree (code);


--
-- Name: ItemkuOrder_order_id_key; Type: INDEX; Schema: trx; Owner: admin
--

CREATE UNIQUE INDEX "ItemkuOrder_order_id_key" ON trx."ItemkuOrder" USING btree (order_id);


--
-- Name: ItemkuOrder_order_number_key; Type: INDEX; Schema: trx; Owner: admin
--

CREATE UNIQUE INDEX "ItemkuOrder_order_number_key" ON trx."ItemkuOrder" USING btree (order_number);


--
-- Name: ItemkuProduct_item_id_key; Type: INDEX; Schema: trx; Owner: admin
--

CREATE UNIQUE INDEX "ItemkuProduct_item_id_key" ON trx."ItemkuProduct" USING btree (item_id);


--
-- Name: ProductPrice_buyer_sku_code_key; Type: INDEX; Schema: trx; Owner: admin
--

CREATE UNIQUE INDEX "ProductPrice_buyer_sku_code_key" ON trx."ProductPrice" USING btree (buyer_sku_code);


--
-- Name: CustomerBalanceHistory CustomerBalanceHistory_customerId_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."CustomerBalanceHistory"
    ADD CONSTRAINT "CustomerBalanceHistory_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES trx."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Customer Customer_createdBy_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."Customer"
    ADD CONSTRAINT "Customer_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES trx."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ExtProductToSupplierJunction ExtProductToSupplierJunction_item_id_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExtProductToSupplierJunction"
    ADD CONSTRAINT "ExtProductToSupplierJunction_item_id_fkey" FOREIGN KEY (item_id) REFERENCES trx."ExternalProduct"(item_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ExtProductToSupplierJunction ExtProductToSupplierJunction_product_id_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExtProductToSupplierJunction"
    ADD CONSTRAINT "ExtProductToSupplierJunction_product_id_fkey" FOREIGN KEY (product_id) REFERENCES trx."ExternalSupplierProduct"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ExternalProduct ExternalProduct_createdBy_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalProduct"
    ADD CONSTRAINT "ExternalProduct_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES trx."ExternalUser"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ExternalSupplierProduct ExternalSupplierProduct_createdBy_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalSupplierProduct"
    ADD CONSTRAINT "ExternalSupplierProduct_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES trx."ExternalUser"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ExternalTransactionBatch ExternalTransactionBatch_createdBy_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalTransactionBatch"
    ADD CONSTRAINT "ExternalTransactionBatch_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES trx."ExternalUser"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ExternalTransactionHistory ExternalTransactionHistory_createdBy_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalTransactionHistory"
    ADD CONSTRAINT "ExternalTransactionHistory_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES trx."ExternalUser"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ExternalTransactionHistory ExternalTransactionHistory_externalTransactionBatchBatch_i_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalTransactionHistory"
    ADD CONSTRAINT "ExternalTransactionHistory_externalTransactionBatchBatch_i_fkey" FOREIGN KEY ("externalTransactionBatchBatch_id") REFERENCES trx."ExternalTransactionBatch"(batch_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ExternalUserBalanceHistory ExternalUserBalanceHistory_userId_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalUserBalanceHistory"
    ADD CONSTRAINT "ExternalUserBalanceHistory_userId_fkey" FOREIGN KEY ("userId") REFERENCES trx."ExternalUser"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ExternalUser ExternalUser_externalAdminUsersUserId_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ExternalUser"
    ADD CONSTRAINT "ExternalUser_externalAdminUsersUserId_fkey" FOREIGN KEY ("externalAdminUsersUserId") REFERENCES trx."ExternalAdminUsers"("userId") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ItemkuProduct ItemkuProduct_createdBy_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ItemkuProduct"
    ADD CONSTRAINT "ItemkuProduct_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES trx."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ItemkuProduct ItemkuProduct_product_id_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ItemkuProduct"
    ADD CONSTRAINT "ItemkuProduct_product_id_fkey" FOREIGN KEY (product_id) REFERENCES trx."ProductPrice"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Owner Owner_createdBy_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."Owner"
    ADD CONSTRAINT "Owner_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES trx."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductPrice ProductPrice_createdBy_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."ProductPrice"
    ADD CONSTRAINT "ProductPrice_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES trx."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TransactionHistory TransactionHistory_createdBy_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."TransactionHistory"
    ADD CONSTRAINT "TransactionHistory_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES trx."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TransactionHistory TransactionHistory_customer_id_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."TransactionHistory"
    ADD CONSTRAINT "TransactionHistory_customer_id_fkey" FOREIGN KEY (customer_id) REFERENCES trx."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TransactionHistory TransactionHistory_order_id_fkey; Type: FK CONSTRAINT; Schema: trx; Owner: admin
--

ALTER TABLE ONLY trx."TransactionHistory"
    ADD CONSTRAINT "TransactionHistory_order_id_fkey" FOREIGN KEY (order_id) REFERENCES trx."ItemkuOrder"(order_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

